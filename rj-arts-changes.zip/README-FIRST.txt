RJ ARTS — changed files only (13 files)
=======================================

⚠️  YE ZIP THEME UPLOAD KARNE KE LIYE NAHI HAI.
    Sirf copy-paste ke liye hai. Upload ke liye "rj-arts-theme.zip" use karein.

Paste karne ka SAHI tarika (zaroori)
------------------------------------
1. File kholein
2. Editor ke andar click -> Ctrl+Home
3. Ctrl+A            (sab select)
4. Seedha Ctrl+V     (paste hi replace kar dega — beech me Delete/Backspace NA dabayein)
5. Ctrl+S

Agar pehle delete karke paste karenge to Shopify samajhta hai file delete karni hai
aur popup deta hai: "config/settings_data.json could not be deleted".

Kaise use karein
----------------
1. Shopify -> Online Store -> Themes -> Dawn (16.1.0) -> ... -> Duplicate
2. Duplicate -> ... -> Edit code
3. Is folder ki har file ko code editor ki SAME path wali file me paste karein.
   Nayi files (jo Dawn me nahi hain) ke liye folder par right-click -> New file.

Files — isi order me paste karein
---------------------------------
 1. config/settings_schema.json      -> REPLACE (poora)
 2. config/settings_data.json        -> REPLACE (poora)
 3. assets/rj-arts.css               -> NAYI FILE
 4. assets/rj-arts.js                -> NAYI FILE
 5. layout/theme.liquid              -> REPLACE (poora)
 6. sections/announcement-bar.liquid -> REPLACE (poora)
 7. sections/header.liquid           -> REPLACE (poora)
 8. snippets/header-mega-menu.liquid -> REPLACE (poora)
 9. sections/header-group.json       -> REPLACE (poora)
10. sections/rj-hero.liquid          -> NAYI FILE
11. sections/rj-usp.liquid           -> NAYI FILE
12. sections/footer-group.json       -> REPLACE (poora)
13. templates/index.json             -> REPLACE (poora)

Dawn ki baaki 337 files ko chhedna nahi hai — isliye ye zip me nahi hain.

Fonts ke baare me
-----------------
Purani file me "cormorant_garamond_n4" / "jost_n4" handles the, jo aapke store ke
font library me valid nahi hain — isi se FileSaveError aata tha.
Ab wo keys hata di gayi hain. Type (Cormorant Garamond + Jost) theme.liquid se
Google Fonts ke through aata hai, aur jaisi hi aap Typography panel me koi font
chunenge, wo aapka chuna font use hone lagega.

Zyada detail: repo me MANUAL-STEPS.md

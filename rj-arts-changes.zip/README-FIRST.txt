RJ ARTS - changed files only (16 files)
=======================================

>>> IS ROUND ME SIRF YE 6 FILES (baaki sab pehle se aapke theme me hai):
      config/settings_data.json     (Colours panel + banner isi se theek hoga)
      assets/rj-arts.css            (2267 lines - har round me badalti hai)
      assets/rj-arts.js             (182 lines - showroom tabs)
      sections/rj-band.liquid       (NAYI - Feature band: Art of Rest)
      sections/rj-showroom.liquid   (NAYI - Showroom edit)
      sections/rj-categories.liquid (NAYI - Category tiles)
      templates/index.json          (in sab ko homepage par add karta hai)

    announcement-bar.liquid paste karne ki zaroorat NAHI - aapki already set
    hai. Design me ticker sticky nahi hai, header sticky hai, isliye scroll
    down par bar upar chala jata hai (yehi intended behaviour hai).

⚠️  YE ZIP THEME UPLOAD KARNE KE LIYE NAHI HAI.
    Sirf copy-paste ke liye hai. Upload ke liye "rj-arts-theme.zip" use karein.

Paste karne ka tarika (har file):
  Ctrl+Home -> Ctrl+A -> Ctrl+V -> Ctrl+S
  (beech me Delete/Backspace kabhi na dabayein, warna
   "config/settings_data.json could not be deleted" popup aata hai)

---- REPLACE (9 files) ----
  config/settings_schema.json          1551 lines
  config/settings_data.json             382 lines  <- colours/fonts/cart yahin se
  layout/theme.liquid                   641 lines
  sections/announcement-bar.liquid       180 lines
  sections/header.liquid                 721 lines
  snippets/header-mega-menu.liquid       134 lines
  sections/header-group.json             145 lines
  sections/footer-group.json              61 lines
  templates/index.json                   212 lines

---- NAYI FILE - sections me New file banakar paste karein ----
  sections/rj-hero.liquid                411 lines
  sections/rj-usp.liquid                 145 lines
  sections/rj-showroom.liquid            357 lines   <- NAYA (Showroom edit)
  sections/rj-categories.liquid          201 lines   <- NAYA (Category tiles)
  sections/rj-band.liquid                187 lines   <- NAYA (Feature band)
  assets/rj-arts.css                    2267 lines   <- poora replace
  assets/rj-arts.js                      182 lines

---- manual/ - OPTIONAL (sirf patch karna ho to) ----
  manual/snippet-1-color-scheme-fallback.liquid   102 lines
  manual/snippet-2-rj-tokens.liquid                14 lines
  manual/snippet-3-settings-schema-rj-group.json   81 lines

Dawn ke baaki 335 files bilkul stock rahenge - base.css / global.js ko haath
nahi lagana.

⚠️  AGAR THEME ME config/settings_data.json HI NAHI DIKH RAHA
    (editor banner "The configuration file config/settings_data.json needs to
    be added..." + Colours panel me "No color schemes defined"):
    MANUAL-STEPS.md -> section 5.1 dekhein. Short version:
      1) Edit code -> config -> file ho to Step 2 ka content paste karein
      2) file na ho to config me New file -> naam `settings_data.json` -> paste
      3) New file option na mile to Customize me koi chhota change -> Save
         (Shopify file khud bana dega), phir content paste karein
      4) Phir bhi na ho to theme delete -> `rj-arts-theme.zip` dobara upload

Pura step-by-step guide + merchant data-entry checklist: MANUAL-STEPS.md

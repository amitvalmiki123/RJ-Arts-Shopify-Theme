RJ ARTS — changed files only (13 files)
=======================================

⚠️  YE ZIP THEME UPLOAD KARNE KE LIYE NAHI HAI.
    Sirf copy-paste ke liye hai. Upload ke liye "rj-arts-theme.zip" use karein.

Kaise use karein
----------------
1. Shopify → Online Store → Themes → Dawn (16.1.0) → ⋯ → Duplicate
2. Duplicate → ⋯ → Edit code
3. Is folder ki har file ko code editor ki SAME path wali file me
   Ctrl+A → paste → Save karein.
   Nayi files (jo Dawn me nahi hain) ke liye folder par right-click → New file.

Files — isi order me paste karein
---------------------------------
 1. config/settings_schema.json      → REPLACE (poora)
 2. config/settings_data.json        → REPLACE (poora)
 3. assets/rj-arts.css               → NAYI FILE
 4. assets/rj-arts.js                → NAYI FILE
 5. layout/theme.liquid              → REPLACE (poora)
 6. sections/announcement-bar.liquid → REPLACE (poora)
 7. sections/header.liquid           → REPLACE (poora)
 8. snippets/header-mega-menu.liquid → REPLACE (poora)
 9. sections/header-group.json       → REPLACE (poora)
10. sections/rj-hero.liquid          → NAYI FILE
11. sections/rj-usp.liquid           → NAYI FILE
12. sections/footer-group.json       → REPLACE (poora)
13. templates/index.json             → REPLACE (poora)

Dawn ki baaki 337 files ko chhedna nahi hai — isliye ye zip me nahi hain.

Zyada detail: repo me MANUAL-STEPS.md

RJ ARTS - changed files only (20 files)
=======================================

>>> IS ROUND ME SIRF YE 3 FILES (Wishlist Hero integration):
      assets/rj-arts.css            (3397 lines - Wishlist Hero icon CSS)
      sections/header.liquid        (820 lines - wishlist mode = Wishlist Hero)
      sections/header-group.json    (150 lines - mode set to wishlist-hero)

      config/settings_data.json     (382 lines - Colours panel, AB TAK PENDING)

    Wishlist Hero app: Launch Point Type = "As a menu item" karein.
    Icon "#hero-wishlist" par jata hai. Duplicate icon issue ho to
    MANUAL-STEPS.md section 6.3 dekhein.

    announcement-bar.liquid paste karne ki zaroorat NAHI - aapki already set
    hai. Design me ticker sticky nahi hai, header sticky hai, isliye scroll
    down par bar upar chala jata hai (yehi intended behaviour hai).

⚠️  YE ZIP THEME UPLOAD KARNE KE LIYE NAHI HAI.
    Sirf copy-paste ke liye hai. Upload ke liye "rj-arts-theme.zip" use karein.

Paste karne ka tarika (har file):
  Ctrl+Home -> Ctrl+A -> Ctrl+V -> Ctrl+S
  (beech me Delete/Backspace kabhi na dabayein, warna
   "config/settings_data.json could not be deleted" popup aata hai)

---- REPLACE (10 files) ----
  config/settings_schema.json          1551 lines
  config/settings_data.json             382 lines  <- colours/fonts/cart yahin se
  layout/theme.liquid                   641 lines
  sections/announcement-bar.liquid       180 lines
  sections/header.liquid                 820 lines
  snippets/header-mega-menu.liquid       134 lines
  sections/header-group.json             150 lines
  sections/footer-group.json              63 lines
  sections/footer.liquid                447 lines   <- REPLACE (Dawn ki file)
  templates/index.json                   416 lines

---- NAYI FILE - sections me New file banakar paste karein ----
  sections/rj-hero.liquid                411 lines
  sections/rj-usp.liquid                 145 lines
  sections/rj-showroom.liquid            357 lines   <- NAYA (Showroom edit)
  sections/rj-categories.liquid          201 lines   <- NAYA (Category tiles)
  sections/rj-band.liquid                188 lines   <- NAYA (Feature band)
  sections/rj-about.liquid               220 lines   <- NAYA (About story)
  sections/rj-best.liquid                239 lines   <- NAYA (Best sellers)
  sections/rj-collections.liquid         212 lines   <- NAYA (Collection carousel)
  sections/rj-reviews.liquid             272 lines   <- Reviews (Judge.me source)
  assets/rj-arts.css                    3397 lines   <- poora replace
  assets/rj-arts.js                      211 lines

---- manual/ - OPTIONAL (sirf patch karna ho to) ----
  manual/snippet-1-color-scheme-fallback.liquid   102 lines
  manual/snippet-2-rj-tokens.liquid                14 lines
  manual/snippet-3-settings-schema-rj-group.json   81 lines

Dawn ke baaki 335 files bilkul stock rahenge - base.css / global.js ko haath
nahi lagana.

⚠️  AGAR THEME ME config/settings_data.json HI NAHI DIKH RAHA
    (editor banner "The configuration file config/settings_data.json needs to
    be added..." + Colours panel me "No color schemes defined"):
    MANUAL-STEPS.md -> section 5.1 dekhein. Short version:
      1) Edit code -> config -> file ho to Step 2 ka content paste karein
      2) file na ho to config me New file -> naam `settings_data.json` -> paste
      3) New file option na mile to Customize me koi chhota change -> Save
         (Shopify file khud bana dega), phir content paste karein
      4) Phir bhi na ho to theme delete -> `rj-arts-theme.zip` dobara upload

Pura step-by-step guide + merchant data-entry checklist: MANUAL-STEPS.md
